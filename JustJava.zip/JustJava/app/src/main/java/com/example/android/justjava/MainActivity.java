/**
 * IMPORTANT: Make sure you are using the correct package name.
 * This example uses the package name:
 * package com.example.android.justjava
 * If you get an error when copying this code into Android studio, update it to match the package name found
 * in the project's AndroidManifest.xml file.
 **/

package com.example.android.justjava;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;

/**
 * This app displays an order form to order coffee.
 */
public class MainActivity extends AppCompatActivity {
    int quantity = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the order button is clicked.
     */
    public void submitOrder(View view) {
        EditText nameField = findViewById(R.id.name_field);
        String name = nameField.getText().toString();

        CheckBox creamCheckBox = findViewById(R.id.whipped_cream_checkbox);
        boolean hasCream = creamCheckBox.isChecked();

        CheckBox chocolateCheckBox = findViewById(R.id.chocolate_checkbox);
        boolean hasChocolate = chocolateCheckBox.isChecked();


        int price = calculatePrice(hasCream, hasChocolate);

        String subject = getString(R.string.order_for, name);
        String message = createOrderSummary(name, hasCream, hasChocolate, price);

        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL, new String[] { "peta.janik@email.cz" });
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, message);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    public String createOrderSummary(String name, boolean hasCream, boolean hasChocolate, int price) {

        String priceMessage = getString(R.string.name) + ": " + name;
        priceMessage += "\n" + getString(R.string.add_cream) + " " + hasCream;
        priceMessage += "\n" + getString(R.string.add_chocolate) + " " + hasChocolate;
        priceMessage += "\n" + getString(R.string.quantity) +": " + quantity;
        priceMessage += "\n" + getString(R.string.total, NumberFormat.getCurrencyInstance().format(price));
        priceMessage += "\n" + getString(R.string.thank_you);
        return priceMessage;
    }
    /**
     * This method is called when the + button is clicked.
     */
    /**
     * @return total price
     */
    private int calculatePrice(boolean hasCream, boolean hasChocolate) {
        int pricePerCup = 5;
        if (hasCream) {
            pricePerCup += 1;
        }
        if (hasChocolate) {
            pricePerCup += 2;
        }
        return pricePerCup * quantity;
    }

    public void increment(View view) {
        if (quantity < 100) {
            quantity += 1;
        }
        else {
            Context context = getApplicationContext();
            CharSequence text = getString(R.string.max);
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        display(quantity);
    }

    /**
     * This method is called when the - button is clicked.
     */
    public void decrement(View view) {
        if (quantity > 1) {
            quantity -= 1;
        }
        else {
            Context context = getApplicationContext();
            CharSequence text = getString(R.string.min);
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        display(quantity);

    }


    /**
     * This method displays the given quantity value on the screen.
     *
     */
    private void display(int number) {
        TextView quantityTextView = (TextView) this.findViewById(R.id.quantity_text_view);
        quantityTextView.setText("" + number);
    }

}